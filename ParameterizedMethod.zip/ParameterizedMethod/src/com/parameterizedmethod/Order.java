package com.parameterizedmethod;

public class Order {
	int oid;
	String oname;

}
