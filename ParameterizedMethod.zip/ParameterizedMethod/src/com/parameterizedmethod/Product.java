package com.parameterizedmethod;

public class Product {
	int pid;
	String pname;
	float price;

}
