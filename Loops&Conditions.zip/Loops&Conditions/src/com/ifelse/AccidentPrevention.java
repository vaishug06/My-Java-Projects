package com.ifelse;

public class AccidentPrevention {
	public static void main(String[] args) {
		int bikespeed=40;
		if(bikespeed<=80) {
			System.out.println("You are safe");
		}
		else {
			System.out.println("You are not safe");
		}
	}

}
