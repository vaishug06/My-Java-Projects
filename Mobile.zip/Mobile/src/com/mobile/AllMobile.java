package com.mobile;

public class AllMobile {
	Mobile m1=new Mobile();
	Mobile m2=new Mobile();

}
