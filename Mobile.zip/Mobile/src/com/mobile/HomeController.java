package com.mobile;

public class HomeController {
	public static void main(String[] args) {
		MobileShopee m3=new MobileShopee();
		Mobile mob=m3.getMobileData();
		System.out.println(mob.company+" "+mob.price+" "+mob.discount);
		
		AllMobile mob1=m3.getAllMobileData();
		System.out.println();
		System.out.println(mob1.m1.company+" "+mob1.m1.price+" "+mob1.m1.discount);
		System.out.println();
		System.out.println(mob1.m2.company+" "+mob1.m2.price+" "+mob1.m2.discount);
		System.out.println();
		
		AllMobiles a1=m3.getData();
		System.out.println(a1.a.m1.company+" "+" "+a1.a.m1.price+" "+a1.a.m1.discount);
		System.out.println(a1.a.m2.company+" "+" "+a1.a.m2.price+" "+a1.a.m2.discount);
		
	}

}
