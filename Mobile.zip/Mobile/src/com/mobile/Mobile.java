package com.mobile;

public class Mobile {
	String company;
	int price;
	float discount;

}
