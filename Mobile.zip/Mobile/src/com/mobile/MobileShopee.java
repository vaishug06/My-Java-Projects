package com.mobile;

public class MobileShopee {
	public Mobile getMobileData() {
		Mobile m=new Mobile();
		m.company="Apple";
		m.price=95000;
		m.discount=3500;
		return m;
	}
	
	public AllMobile getAllMobileData() {
		AllMobile a=new AllMobile();
		a.m1.company="OPPO";
		a.m1.price=45000;
		a.m1.discount=5000;
		
		a.m2.company="VIVO";
		a.m2.price=50000;
		a.m2.discount=5000;
		
		return a;
	}
	
	public AllMobiles getData() {
		AllMobiles a1=new AllMobiles();
		a1.a.m1.company="OPPO";
		a1.a.m1.price=56000;
		a1.a.m1.discount=6000;
		
		a1.a.m2.company="VIVO";
		a1.a.m2.price=50000;
		a1.a.m2.discount=5000;
		return a1;
	}

}
