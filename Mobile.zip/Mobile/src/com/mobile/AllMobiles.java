package com.mobile;

public class AllMobiles {
	AllMobile a=new AllMobile();

}
