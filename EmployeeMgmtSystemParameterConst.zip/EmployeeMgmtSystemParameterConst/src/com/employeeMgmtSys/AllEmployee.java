package com.employeeMgmtSys;

public class AllEmployee {
	Employee e1;
	Employee e2;
	Employee e3;
	
	public AllEmployee(Employee emp1, Employee emp2, Employee emp3) {
		e1=emp1;
		e2=emp2;
		e3=emp3;
	}

}
