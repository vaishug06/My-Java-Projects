package com.ExceptionHandling;

public class MathematicalException extends RuntimeException {
	public MathematicalException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
