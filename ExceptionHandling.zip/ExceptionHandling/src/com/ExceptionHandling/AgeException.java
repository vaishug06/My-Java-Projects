package com.ExceptionHandling;

public class AgeException extends RuntimeException {
	public AgeException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
