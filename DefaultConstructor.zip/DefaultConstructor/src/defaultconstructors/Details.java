package defaultconstructors;

public class Details {
	int marks;
	String result;
	
	public Details()
	{
		System.out.println("Default constructor from Details class");
		
	}
	
	public void d1()
	{
		System.out.println("Your result is:");
	}

}
