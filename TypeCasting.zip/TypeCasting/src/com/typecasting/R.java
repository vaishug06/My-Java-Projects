package com.typecasting;

public class R extends Q{
int k=600;
	
	public void m3() {
		System.out.println("m3 method of class R");
	}
}
