package com.typecasting;

public class WideningCasting {//implcit typecasting
	public static void main(String[] args) {
		byte b=120;
		short s=b;
		System.out.println(b);
		int i=b;
		System.out.println(i);
		float f=b;
		System.out.println(f);
		long l=b;
		System.out.println(l);
		
	}

}
