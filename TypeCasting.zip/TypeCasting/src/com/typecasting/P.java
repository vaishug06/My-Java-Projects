package com.typecasting;

public class P {
	int i=100;
	
	public P m1() {
		System.out.println("m1 method of class P");
		P p=new P();
		return p;
	}

}
