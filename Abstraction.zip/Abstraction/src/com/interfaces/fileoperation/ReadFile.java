package com.interfaces.fileoperation;

public class ReadFile implements FileOperation {

	@Override
	public void processFile() {
		System.out.println("File read operation completed!");
		
	}

}
