package com.interfaces.fileoperation;

public class DeleteFile implements FileOperation{

	@Override
	public void processFile() {
		System.out.println("File Deleted!");
		
	}

}
