package com.vehiclerentalsystem;

/*
Create a Vehicle Rental System where a Vehicle class 
has an overloaded bookVehicle() method that allows booking
by days, hours, or location. The Car and Bike subclasses
override the calculateRentalPrice() 
method to apply specific rental pricing strategies.*/

public class Bike extends Vehicle {
	@Override
	public void calculateRentalPrice(float chrgs,float time) {
		// TODO Auto-generated method stub
		//super.calculateRentalPrice(charges, time);
		float bikechgs=1000;
		float total=(chrgs*time)+bikechgs;
		System.out.println("Total fares:"+total);
	}

}
