package com.vehiclerentalsystem;
/*
Create a Vehicle Rental System where a Vehicle class 
has an overloaded bookVehicle() method that allows booking
by days, hours, or location. The Car and Bike subclasses
override the calculateRentalPrice() 
method to apply specific rental pricing strategies.*/

public class Car extends Vehicle{
	@Override
	public void calculateRentalPrice(float chrgs,float time) {
		// TODO Auto-generated method stub
		float carchgs=1000;
		float total=(chrgs*time)+carchgs;
		System.out.println("Total fares:"+total);
	}

}
