package com.vehiclerentalsystem;

/*Create a Vehicle Rental System where a Vehicle class 
 * has an overloaded bookVehicle() method that allows 
 * booking by days, hours, or location. The Car and Bike 
 * subclasses override the calculateRentalPrice() method
 *  to apply specific rental pricing strategies.*/

public class Vehicle {
	public void bookVehicle(int days) {

	}

	public void bookVehicle(float hrs) {
		
	}

	public void bookVehicle(String location) {
		
	}

	public void calculateRentalPrice(float chrgs, float time) {
		System.out.println("Default charges for  Car: 1000\t Bike: 500");
		
	}

}
