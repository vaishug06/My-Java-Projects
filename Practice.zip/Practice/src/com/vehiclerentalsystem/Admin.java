package com.vehiclerentalsystem;

import java.util.*;

/*
Create a Vehicle Rental System where a Vehicle class 
has an overloaded bookVehicle() method that allows booking
by days, hours, or location. The Car and Bike subclasses
override the calculateRentalPrice() 
method to apply specific rental pricing strategies.*/

public class Admin {
	public static void main(String[] args) {
		System.out.println("Choose one option:");
		System.out.println("1. Book a car");
		System.out.println("2. Book a bike");
		Scanner sc = new Scanner(System.in);
		int ch = sc.nextInt();
		switch (ch) {
		case 1: {

			Car c = new Car();
			System.out.println("Select Booking type:");
			System.out.println("1. By no.of hours");
			System.out.println("2. By no. of days");
			System.out.println("3. By location");

			int c2 = sc.nextInt();
			switch (c2) {
			case 1: {
				System.out.println("Enter no. of hours:");
				float hrs = sc.nextFloat();
				int hrlychrgs=500;
				c.bookVehicle(hrs);
				c.calculateRentalPrice(hrlychrgs,hrs);
				break;

			}
			case 2: {
				System.out.println("Enter no. of days:");
				float days = sc.nextFloat();
				float dailychrgs=1000;
				c.bookVehicle(days);
				c.calculateRentalPrice(dailychrgs,days);
				break;
			}
			case 3: {
				System.out.println("Enter location:");
				String loc = sc.nextLine();
				c.bookVehicle(loc);
				//c.calculateRentalPrice(days);
			}
			}

		}
		case 2: {
		Bike b=new Bike();	
		System.out.println("Select Booking type:");
		System.out.println("1. By no.of hours");
		System.out.println("2. By no. of days");
		System.out.println("3. By location");

		int c2 = sc.nextInt();
		switch (c2) {
		case 1: {
		System.out.println("Enter no. of hours:");
		float hrs = sc.nextFloat();
		int hrlychrgs=500;
		b.bookVehicle(hrs);
		b.calculateRentalPrice(hrlychrgs,hrs);
		break;

		}
		case 2: {
			System.out.println("Enter no. of days:");
			float days = sc.nextFloat();
			float dailychrgs=1000;
			b.bookVehicle(days);
			b.calculateRentalPrice(dailychrgs,days);
			break;
		}
		case 3: {
			System.out.println("Enter location:");
			String loc = sc.nextLine();
			b.bookVehicle(loc);
			//c.calculateRentalPrice(days);
			break;
		}
			
		}
		default:{
			throw new IllegalArgumentException("Unexpected value: " + ch);
		}
	}

}

/*
 * c.bookVehicle(5); c.calculateRentalPrice(1000, 5); break;
 */
/*
 * Bike b = new Bike(); b.bookVehicle(5.5f); break;
 */
