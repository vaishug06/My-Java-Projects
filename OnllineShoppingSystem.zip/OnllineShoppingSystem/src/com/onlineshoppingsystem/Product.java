package com.onlineshoppingsystem;

public class Product {
	void displayDetails() {
		System.out.println("Default Product Details");
	}
	
	void calculateShippingCost() {
		System.out.println("Default Shipping cost: Rs. 150");
	}

}
