package com.mobilemgmtsys;

public class AllMobile {
	Mobile m1;
	Mobile m2;
	Mobile m3;
	
	public AllMobile(Mobile mob1, Mobile mob2, Mobile mob3) {
		m1=mob1;
		m2=mob2;
		m3=mob3;
	}

}
