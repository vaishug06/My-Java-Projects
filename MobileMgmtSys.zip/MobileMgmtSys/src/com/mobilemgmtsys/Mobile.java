package com.mobilemgmtsys;

public class Mobile {
	String company;
	int price;
	float discount;
	
	public Mobile(String mname, int mprice, float mdisc) {
		company=mname;
		price=mprice;
		discount=mdisc;
		
	}

}
