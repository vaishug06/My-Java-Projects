package com.mobilemgmtsys;

public class MoblieShopee {

	public Mobile addMobile() {
		Mobile m=new Mobile("Oppo", 50000, 2000);
		return m;
	}
	
	public AllMobile addAllMobile() {
		Mobile m1=new Mobile("Vivo", 70000, 5000);
		Mobile m2=new Mobile("Samsung", 80000, 5000);
		Mobile m3=new Mobile("Apple", 90000, 2500);
		AllMobile all=new AllMobile(m1,m2,m3);
		return all;
	}
}
