package com.package2;

public class Details {
	int marks =450;
	
	public void printResult() {
		System.out.println("Your percentage: 90");
	}

}
