package com.finalkeyword;

public final class FinalKeywordExample1 {
	final int id;
	final String name;
	
	public FinalKeywordExample1() {
		// TODO Auto-generated constructor stub
		id=10;
		name="Abc";
	}
	
	final public void m1() {
		System.out.println("m1 from FinalKeywordExample1");
	}

}
