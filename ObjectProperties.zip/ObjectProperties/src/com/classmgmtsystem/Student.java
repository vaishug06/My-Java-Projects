package com.classmgmtsystem;

public class Student {
	int sId;
	String sName;
	Batch b=new Batch();

}
