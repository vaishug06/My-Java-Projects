package com.classmgmtsystem;

public class Faculty {
	int fId;
	String fName;
	Course c=new Course();

}
