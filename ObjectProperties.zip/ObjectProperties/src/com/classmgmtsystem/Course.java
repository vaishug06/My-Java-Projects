package com.classmgmtsystem;

public class Course {
	int cId;
	String cName;

}
