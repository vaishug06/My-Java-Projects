package com.classmgmtsystem;

public class Batch {
	int bId;
	String bName;
	Faculty f=new Faculty();

}
