package com.multilevelinheritance;

public class ClassA {
	int aid=60;
	
	public void m1() {
		System.out.println("m1 method from ClassA");
	}

}
