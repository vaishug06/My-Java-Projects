package com.multilevelinheritance;

public class ClassB extends ClassA{
	
	int bid=70;
	
	public void m2() {
		System.out.println("m2 method from ClassB");
	}

}
