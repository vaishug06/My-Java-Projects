package com.vehicleinheritance;

public class Xuv700 extends Mahindra{
	int noOfAirBags=2;
	boolean hasTouchscreenDisplay=true;
	
	public void details() {
		System.out.println("XUV 700 car of Mahindra Company");
	}

}
