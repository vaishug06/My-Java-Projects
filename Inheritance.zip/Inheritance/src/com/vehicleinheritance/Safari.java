package com.vehicleinheritance;

public class Safari extends Tata{
	
	int modelNo=535786;
	
	public void details() {
		System.out.println("Safari car of Tata Company");
	}

}
