package com.vehicleinheritance;

public class Vehicle {
	int noOfWheels=4;
	int noOfSeats=5;
	
	public void startEngine() {
		System.out.println("Engine Started");
	}
	
	public void stopEngine() {
		System.out.println("Engine Stopped");
		
	}

}
