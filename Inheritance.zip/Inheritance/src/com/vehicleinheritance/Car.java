package com.vehicleinheritance;

public class Car extends Vehicle {
	
	int seatingCapacity= 5;
	int noOfDoors=4;
	
	public void playMusic() {
		System.out.println("Music Started");
	}
	
	public void stopMusic() {
		System.out.println("Music Stopped");
	}
	

}
