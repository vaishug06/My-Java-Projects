package com.vehicleinheritance;

public class Nexon extends Tata{
	boolean hastouchScreenDisplay=true;
	
	public void details() {
		System.out.println("Nexon car of Tata Company");
	}

}
