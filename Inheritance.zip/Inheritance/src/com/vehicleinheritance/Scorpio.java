package com.vehicleinheritance;

public class Scorpio extends Mahindra{
	public void details() {
		System.out.println("XUV 700 car of Mahindra Company");
	}


}
