package com.vehicleinheritance;

public class Harrier extends Tata{
	int noOfAirBags=4;
	boolean hassunRoof=false;
	
	public void details() {
		System.out.println("Harrier car of Tata Company");
	}

}
