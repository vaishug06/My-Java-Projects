package com.hierarchicalinheritance;

public class Father {
	int fage=60;
	String fName="Abc";
	
	public void m1() {
		System.out.println("m1 method of Father class");
	}

}
