package com.hierarchicalinheritance;

public class Son extends Father{
	int sage=30;
	String sName="Xyz";
	
	public void m2() {
		System.out.println("m2 method from Son class");
	}

}
