package com.singleinheritance;

public class ParentClass {
	int pid=20;
	
	public void m1() {
		System.out.println("ParentClass method");
	}

}
