package com.emloyeemgmtsystem;

public class Employee {
	int id;
	String name;
	float salary;

}
