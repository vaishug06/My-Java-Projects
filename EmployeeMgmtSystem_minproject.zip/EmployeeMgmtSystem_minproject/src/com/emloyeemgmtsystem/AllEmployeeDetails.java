package com.emloyeemgmtsystem;

public class AllEmployeeDetails {
	Employee pqr=new Employee();
	Employee xzy=new Employee();
	Employee efg=new Employee();

}
