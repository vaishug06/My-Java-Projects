
public class abc {
	public static void main(String[] args) {
		int i = 10;
		if (i == 10) {
			System.out.println("True"+i);
		} else {
			System.out.println("False"+i);
		}
	}
}
