package com.productmgmtsystem;

public class Customer {
	int cId;
	String cName;
	String address;
	String emailId;
	long contactNo;

}
