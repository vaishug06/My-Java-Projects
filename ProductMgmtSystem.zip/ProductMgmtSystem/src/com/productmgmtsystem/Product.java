package com.productmgmtsystem;

public class Product {
	int pId;
	String pName;
	
}
