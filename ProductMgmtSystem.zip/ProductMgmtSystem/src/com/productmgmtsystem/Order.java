package com.productmgmtsystem;

public class Order {
	int oId;
	String oName;
	String date;
	float oPrice;

}
