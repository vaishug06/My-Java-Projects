package com.emp;

public class AllEmployee {
	Employee e1=new Employee();
	Employee e2=new Employee();
	Employee e3=new Employee();

}
