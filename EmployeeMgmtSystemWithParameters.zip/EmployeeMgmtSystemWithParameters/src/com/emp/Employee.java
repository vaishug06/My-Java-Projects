package com.emp;

public class Employee {

	int eid;
	String name;
	double salary;
}
