package com.accessmodifiers2;
import com.accesmodifiersexample.*;

public class MainDefaultTest {
	public static void main(String[] args) {
		DefaultTest dt=new DefaultTest();
		System.out.println(dt.id);
		dt.m2()
		
		
	}

}
