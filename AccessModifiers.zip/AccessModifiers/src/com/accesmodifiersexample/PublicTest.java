package com.accesmodifiersexample;

public class PublicTest {
	public int testid=20;
	
	public PublicTest() {
		
	}
	
	public void m3() {
		System.out.println("Public method m3");
	}
	

}
