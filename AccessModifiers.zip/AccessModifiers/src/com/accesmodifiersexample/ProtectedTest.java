package com.accesmodifiersexample;

public class ProtectedTest {
	
	protected int id=10;
	protected String name="Abc";
	
	protected void m1() {
		System.out.println("m1 method");
		
	}

}
