package com.accesmodifiersexample;

public class DemoDefault {
	public static void main(String[] args) {
		DefaultTest d=new DefaultTest();
		System.out.println(d.id);
		d.m2();
	}

}
