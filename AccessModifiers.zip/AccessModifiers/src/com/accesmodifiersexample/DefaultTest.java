package com.accesmodifiersexample;

public class DefaultTest {
	int id=400;
	
	DefaultTest(){
		
	}
	
	void m2() {
		System.out.println("Default access modifier");
	}
	
	
}
