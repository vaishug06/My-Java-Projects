package com.example.calculator.ui;
import com.example.calculator.service.CalculatorService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

@Component
public class CalculatorUI implements CommandLineRunner{
	private final CalculatorService calculatorService;

    public CalculatorUI(CalculatorService calculatorService) {
        this.calculatorService = calculatorService;
    }
    @Override
    public void run(String... args) {
        JFrame frame = new JFrame("Simple Calculator");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 400);

        JTextField num1Field = new JTextField();
        JTextField num2Field = new JTextField();
        JTextField resultField = new JTextField();
        resultField.setEditable(false);

        JButton addButton = new JButton("+");
        JButton subButton = new JButton("-");
        JButton mulButton = new JButton("*");
        JButton divButton = new JButton("/");

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 2));
        panel.add(new JLabel("Number 1:"));
        panel.add(num1Field);
        panel.add(new JLabel("Number 2:"));
        panel.add(num2Field);
        panel.add(new JLabel("Result:"));
        panel.add(resultField);
        panel.add(addButton);
        panel.add(subButton);
        panel.add(mulButton);
        panel.add(divButton);

        frame.add(panel);
        frame.setVisible(true);

        // Event Handling
        ActionListener actionListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    double num1 = Double.parseDouble(num1Field.getText());
                    double num2 = Double.parseDouble(num2Field.getText());
                    double result = 0;

                    if (e.getSource() == addButton) {
                        result = calculatorService.add(num1, num2);
                    } else if (e.getSource() == subButton) {
                        result = calculatorService.subtract(num1, num2);
                    } else if (e.getSource() == mulButton) {
                        result = calculatorService.multiply(num1, num2);
                    } else if (e.getSource() == divButton) {
                        result = calculatorService.divide(num1, num2);
                    }
                    resultField.setText(String.valueOf(result));
                } catch (Exception ex) {
                    resultField.setText("Error");
                }
            }
        };

        addButton.addActionListener(actionListener);
        subButton.addActionListener(actionListener);
        mulButton.addActionListener(actionListener);
        divButton.addActionListener(actionListener);
    }

}
