package com.example.calculator.calculator_app;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {

    @GetMapping("/")
    public String home() {
        return "Welcome to the Calculator App!";
    }

    @GetMapping("/add")
    public String add(@RequestParam double a, @RequestParam double b) {
        double result = a + b;
        return "The result of addition is: " + result;
    }

    @GetMapping("/subtract")
    public String subtract(@RequestParam double a, @RequestParam double b) {
        double result = a - b;
        return "The result of subtraction is: " + result;
    }

    @GetMapping("/multiply")
    public String multiply(@RequestParam double a, @RequestParam double b) {
        double result = a * b;
        return "The result of multiplication is: " + result;
    }

    @GetMapping("/divide")
    public String divide(@RequestParam double a, @RequestParam double b) {
        if (b == 0) {
            return "Error: Division by zero is not allowed!";
        }
        double result = a / b;
        return "The result of division is: " + result;
    }
}
