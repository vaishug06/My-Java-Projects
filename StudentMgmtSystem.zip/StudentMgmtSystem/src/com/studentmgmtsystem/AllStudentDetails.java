package com.studentmgmtsystem;

public class AllStudentDetails {
	Student s1=new Student();
	Student s2=new Student();
	Student s3=new Student();

}
