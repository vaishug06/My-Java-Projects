package com.studentmgmtsystem;

public class Student {
	int id;
	String name;
	String address;

}
